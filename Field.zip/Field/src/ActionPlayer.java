import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;


public class ActionPlayer {
	StatPanel stat_panel = new StatPanel();
	
		//----------------------BUILD FUNCTION-----------------//
		//parameters: player (includes the coins etc. check Player.java, index_buttons: iyong index naclick na buttons ng user
		public static Player build(Player player,int[]index_buttons,String image_path){
				System.out.println("BUILD!");
				//GET THE NAME OF THE STRUCTURE
				String [] hello = (image_path.split("/"));
				String[]temp = hello[hello.length-1].split(".png");
				String type = temp[0];
				System.out.println(type);			
				
				//edit the state of the player
				player.field.state_buttons[index_buttons[0]][index_buttons[1]] = type; //structure
				
				//edit the UI: pansamantala GOLD na image lang nilagay ko. pero ang naisip ko ay may lalabas na isa pang window with options ng puwede niyang ilagay doon sa button na iyon
				Panel.buttons[index_buttons[0]][index_buttons[1]].setIcon(new ImageIcon(image_path));
				
				player.coins = player.coins - 50; 
			
				return player; //return player (nabago na iyong field at state niya)
				
		}
		
		//-------------------UPGRADE FUNCTION-----------------//
		
		
		//--------------------ATTACK FUNCTION-----------------//
		public static Player attack(Player player1, Player player2){
			//katulad sa build. bale iaccess natin attributes ng each player and mag increment at decrement na lang based sa actions niya (kung nagdagdag ng troops etc)
				System.out.println("ATTACK!");
				return player1;
		}
		//--------------------DEFENSE FUNCTION---------------//
		public static Player defense(Player player1, Player player2){
			//katulad sa build. bale iaccess natin attributes ng each player and mag increment at decrement na lang based sa actions niya (kung nagdagdag ng troops etc)
			
				System.out.println("DEFENSE!");
				return player1;
		}

}
