import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTextArea;

//CHAT: dadagdagan pa dapat ito ng 2 text area at button for send
public class SidePanel extends JPanel {

	JPanel panel = new JPanel();
	
	public SidePanel(){
		this.add(panel);
	}
}
