import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;

//Panel para doon sa options kung mag build, attack or defense ba siya
public class ActionPanel extends JPanel implements ActionListener {
	JPanel panel = new JPanel();
	JButton attack = new JButton(new ImageIcon("images/icons/metal_sword_icon.png"));
	JButton build = new JButton(new ImageIcon("images/icons/assembly_icon.png"));
	JButton upgrade = new JButton(new ImageIcon("images/icons/upgrade.png"));
	
	Panel panel2;
	BattleField field = new BattleField();
	
	
	int []button_index = new int[2];
	int action;
	
	ChoiceWindow window = new ChoiceWindow();
	ChoicePanel choice_panel = new ChoicePanel();
	public ActionPanel(){
		//--------------------------------GUI-------------------------//
		build.setPreferredSize(new Dimension(80,80));
		attack.setPreferredSize(new Dimension(80,80));
		upgrade.setPreferredSize(new Dimension(80,80));
		
		build.addActionListener(this);
		attack.addActionListener(this);
		upgrade.addActionListener(this);
		
		build.setToolTipText("BUILD");
		attack.setToolTipText("ATTACK");
		upgrade.setToolTipText("UPGRADE");
		
		panel.setPreferredSize(new Dimension(300,300));
		panel.setVisible(true);
		panel.add(build);
		panel.add(upgrade);
		panel.add(attack);
		
		this.add(panel);
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == build){ //if pinili niyang magbuild go to class ActionPlayer
			choice_panel.receiveIndex(button_index);
			//if may napindot niya build part. lalabas ang ChoiceWindow
			window.setPreferredSize(new Dimension(500,500));
			window.add(choice_panel);
			window.setVisible(true);
			window.pack();
			
		}//end of build
		
		if(e.getSource() == attack){ //if pinili niyang magattack
			//ActionPlayer.attack(player2,player3);
		}//end of attack
		
		
	}
	
	public int getAction(){
		return action;
	}
	
	
	public void receiveIndex(int []index){
		button_index[0] = index[0];	//row number
		button_index[1] = index[1]; //column number
	}
	
	public int[] getIndex(){
		return button_index;
	}
}
