import java.awt.Dimension;
import javax.swing.JFrame;

//frame para sa action options
public class ActionWindow extends JFrame{
		ActionPanel panel = new ActionPanel();
		JFrame frame = new JFrame("ACTION");
		
	public ActionWindow(){
	}
}
