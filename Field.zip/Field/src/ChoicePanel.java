import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;


public class ChoicePanel extends JPanel implements ActionListener {
	JButton[] struct_button = new JButton[14];
	JPanel panel = new JPanel();
	JPanel army_panel = new JPanel();
	JPanel def_panel = new JPanel();
	JPanel res_panel = new JPanel();
	
	JLabel army = new JLabel("ARMY CAMP\n");
	JLabel def = new JLabel("DEFENSE\n");
	JLabel res = new JLabel("RESOURCE\n");
	String [] image_path = new String[14];
	
	BattleField field = new BattleField();
	Player player1 = new Player("Mary",500,50,field);	//example lang: instance of a player
	Player player2 = new Player("Ayel", 500,50,field);	//example lang: instance of a player
	Player player3 = new Player("Zyrine", 500,50,field);	//example lang: instance of a player
	
	int []button_index = new int[2];
	String type;
	public ChoicePanel(){
		//-------------------GUI-------------------------------//
		
		//ARMY
		image_path[0] = new String("images/structures/army camp/archer queen altar.png");
		image_path[1] = new String("images/structures/army camp/barbarian king altar.png");
		image_path[2] = new String("images/structures/army camp/barracks1.png");
		
		//DEFENSE
		image_path[3] = new String("images/structures/defense/airdefense1.png");
		image_path[4] = new String("images/structures/defense/airsweeper1.png");
		image_path[5] = new String("images/structures/defense/archertower1.png");
		image_path[6] = new String("images/structures/defense/cannon1.png");
		image_path[7] = new String("images/structures/defense/infernotower1.png");
		image_path[8] = new String("images/structures/defense/mortar1.png");
		image_path[9] = new String("images/structures/defense/trapbomb3.png");
		image_path[10] = new String("images/structures/defense/trapspring.png");
		image_path[11] = new String("images/structures/defense/wizardtower1.png");
		image_path[12] = new String("images/structures/defense/xbowground1.png");
		
		//RESOURCE
		image_path[13] = new String("images/structures/resource/goldstorage1.png");
		
		//ARMY CAMP
		army_panel.add(army);
		for(int i =0; i<3;i++){
			struct_button[i] = new JButton(new ImageIcon(image_path[i]));
			struct_button[i].setPreferredSize(new Dimension(80,80));
			struct_button[i].addActionListener(this);
			army_panel.add(struct_button[i]);
		}//end of for loop
		
		//DEFENSE
		def_panel.add(def);
		for(int i = 3; i<13;i++){
			struct_button[i] = new JButton(new ImageIcon(image_path[i]));
			struct_button[i].setPreferredSize(new Dimension(80,80));
			struct_button[i].addActionListener(this);
			def_panel.add(struct_button[i]);
		
		}//end of for loop
		
		//RESOURCE
		res_panel.add(res);
		struct_button[13] = new JButton(new ImageIcon(image_path[13]));
		struct_button[13].setPreferredSize(new Dimension(80,80));
		struct_button[13].addActionListener(this);
		res_panel.add(struct_button[13]);
	
		
		army_panel.setPreferredSize(new Dimension(500,100));
		army_panel.setVisible(true);
		
		def_panel.setPreferredSize(new Dimension(500,200));
		def_panel.setVisible(true);
		
		res_panel.setPreferredSize(new Dimension(500,100));
		res_panel.setVisible(true);
	
		panel.add(army_panel);
		panel.add(def_panel);
		panel.add(res_panel);
		
		panel.setPreferredSize(new Dimension(500,500));
		panel.setVisible(true);
		this.add(panel);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		for(int i =0; i<14;i++){
			if(e.getSource() == struct_button[i]){
				System.out.println(button_index[0]);
				System.out.println(button_index[1]);
				if(i<3){
					type = "A"; //referring to ARMY
				}
				else if(i>=3 && i!=13){
					type = "D"; //referring to DEFENSE
				}
				else if(i == 13){
					type = "R"; //referring to RESOURCE
				}
				ActionPlayer.build(player1,button_index,image_path[i]);
				
			}
		}
		//ActionPlayer.build(player1,getIndex());
		
		
	}
	
	public void receiveIndex(int []index){
		button_index[0] = index[0];	//row number
		button_index[1] = index[1]; //column number
	}
	
}
