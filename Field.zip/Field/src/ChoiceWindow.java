import java.awt.Dimension;
import javax.swing.JFrame;

//frame para sa structure options
public class ChoiceWindow extends JFrame {
	
		ChoicePanel panel = new ChoicePanel();
		JFrame frame = new JFrame("CHOOSE");
			
		public ChoiceWindow(){
		}
}


