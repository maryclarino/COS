import java.awt.Color;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;

//FIELD PANEL: panel para doon sa field/grass part
public class Panel extends JPanel implements ActionListener {
	ActionWindow window = new ActionWindow();
	ChoicePanel choice_panel = new ChoicePanel();
	ActionPanel act_panel = new ActionPanel();
	
	JPanel panel = new JPanel();
	static JButton [][]buttons = new JButton[6][8];
	JButton []troop_button = new JButton[6];
	int [] button_index = new int[2];

	public Panel(){
		//-------------------GUI-------------------------------//
		for(int i =0; i<6;i++){
			for(int j =0; j<8;j++){
				buttons[i][j] = new JButton(new ImageIcon("images/grass.jpg"));
				buttons[i][j].setPreferredSize(new Dimension(80,80));
				buttons[i][j].setBackground(Color.green);
				buttons[i][j].addActionListener(this);
				panel.add(buttons[i][j]);
			}
		}//end of for loop*/
		
		panel.setPreferredSize(new Dimension(680,520));
		panel.setVisible(true);
		this.add(panel);
	}//end of public panel
	
	
	@SuppressWarnings("deprecation")
	public void actionPerformed(ActionEvent e) {
		for(int i =0;i<6;i++){
			for(int j =0;j<6;j++){
				if(e.getSource() == buttons[i][j]){ 
					//store sa array iyong index para malaman anong button inaccess
					button_index[0] = i;
					button_index[1] = j;
					
					act_panel.receiveIndex(button_index);
					
					
					//if may napindot siya sa grass part. lalabas ang ActionWindow
					window.setPreferredSize(new Dimension(300,150));
					window.add(act_panel);
					window.setVisible(true);
					window.pack();
					
					
				}
			}
		}
		
	}
}//end of class
