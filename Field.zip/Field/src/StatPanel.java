import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

//stat panel: UI para mapakita level, coins, experience ng user
public class StatPanel extends JPanel {
	JPanel panel = new JPanel();
	JLabel level = new JLabel("LEVEL");
	JLabel coins = new JLabel("COINS");
	JLabel exp = new JLabel("EXP    ");
	JTextField level_text = new JTextField();
	JTextField coins_text = new JTextField();
	JTextField exp_text = new JTextField();
	
	public StatPanel(){
		panel.add(level);
		panel.add(level_text);
		panel.add(coins);
		panel.add(coins_text);
		panel.add(exp);
		panel.add(exp_text);
		
		level_text.setEditable(false);
		coins_text.setEditable(false);
		exp_text.setEditable(false);
		
		level_text.setText("1");		//initial
		coins_text.setText("500");
		exp_text.setText("50");
		
		
		level_text.setPreferredSize(new Dimension(100,20));
		coins_text.setPreferredSize(new Dimension(100,20));
		exp_text.setPreferredSize(new Dimension(100,20));
		
		panel.setPreferredSize(new Dimension(150,200));
		panel.setVisible(true);
		this.add(panel);
	}//end of class
}
