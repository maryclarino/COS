
public class BattleField {
	String [][]state_buttons = new String [6][8]; //pang store kung anong current state ng field niya
	
	public BattleField(){
		for(int i =0; i<6;i++){
			for(int j = 0; j<6;j++){
				state_buttons[i][j] = "grass";
			}
		}
	}
	
}
