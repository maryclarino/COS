import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;

public class MainWindow extends JFrame {
	//static Panel panel = new Panel();			//panel of the field
	static Panel panel = new Panel();			//panel of the field
	
	static LowPanel low_panel = new LowPanel();	//panel of the troop
	static SidePanel side_panel = new SidePanel();	//panel of the chat
	static StatPanel stats_panel = new StatPanel();	//panel of the stat

	static JFrame window = new JFrame();
	static JInternalFrame troop = new JInternalFrame("TROOP", true,true,true,true);
	
	public static void main(String[]args){
		//-----------------------------------GUI--------------------------------------------
		JFrame frame = new JFrame("COMBAT OF SOLITARY");
		frame.setResizable(false);
		frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		JDesktopPane desktop = new JDesktopPane();
		
		//WINDOW FIELD
		JInternalFrame field = new JInternalFrame("FIELD", true,true,true,true);
		field.add(panel);
		field.setVisible(true);
		field.setBounds(70, 70, 700, 550);
		field.setLocation(300,0);
		
		//TROOP WINDOW
		troop.add(low_panel);
		troop.setVisible(true);
		troop.setBounds(70, 70, 700, 130);
		troop.setLocation(300,550);
		
		//CHAT WINDOW
		JInternalFrame chat = new JInternalFrame("CHAT", true,true,true,true);
		chat.add(side_panel);
		chat.setVisible(true);
		chat.setBounds(70, 70, 300, 480);
		chat.setLocation(0,200);
		
		//CHAT WINDOW
		JInternalFrame stats = new JInternalFrame("STATS", true,true,true,true);
		stats.add(stats_panel);
		stats.setVisible(true);
		stats.setBounds(70, 70, 300, 200);
		stats.setLocation(0,0);
		
		desktop.add(field);
		desktop.add(troop);
		desktop.add(chat);
		desktop.add(stats);
		
		frame.add(desktop);
		frame.setPreferredSize(new Dimension(1010, 720));
		frame.setVisible(true);
		frame.pack();
		
		
	}


}